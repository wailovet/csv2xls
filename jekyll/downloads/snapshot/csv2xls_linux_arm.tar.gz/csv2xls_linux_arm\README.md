# csv2xls
```
csv2xls <infile> <outfile>

example:
csv2xls test.csv test.xlsx
```


[download](jekyll/downloads/snapshot/downloads.md)
